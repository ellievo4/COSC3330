//Thanh Vo_1148524

// my_predictor.h
// This file contains a sample gshare_predictor class.
// It is a simple 32,768-entry gshare with a history length of 15.

#include <iostream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <ctime>

using namespace std;

class gshare_update : public branch_update {
public:
	unsigned int index;
};

class gshare_predictor : public branch_predictor {
public:
#define HISTORY_LENGTH	15
#define TABLE_BITS	15
	gshare_update u;
	branch_info bi;
	unsigned int history;
	unsigned char tab[1<<TABLE_BITS];

	gshare_predictor (void) : history(0) { 
		memset (tab, 0, sizeof (tab));
	}

	branch_update *predict (branch_info & b) {
		bi = b;
		if (b.br_flags & BR_CONDITIONAL) {
			u.index = 
				  (history << (TABLE_BITS - HISTORY_LENGTH)) 
				^ (b.address & ((1<<TABLE_BITS)-1));
			u.direction_prediction (tab[u.index] >> 1);
		} else {
			u.direction_prediction (true);
		}
		u.target_prediction (0);
		return &u;
	}

	void update (branch_update *u, bool taken, unsigned int target) {
		if (bi.br_flags & BR_CONDITIONAL) {
			unsigned char *c = &tab[((gshare_update*)u)->index];
			if (taken) {
				if (*c < 3) (*c)++;
			} else {
				if (*c > 0) (*c)--;
			}
			history <<= 1;
			history |= taken;
			history &= (1<<HISTORY_LENGTH)-1;
		}
	}
};

//
// Pentium M hybrid branch predictors
// This class implements a simple hybrid branch predictor based on the Pentium M branch outcome prediction units. 
// Instead of implementing the complete Pentium M branch outcome predictors, the class below implements a hybrid 
// predictor that combines a bimodal predictor and a global predictor. 
struct Global {
	unsigned int tag;
	unsigned char two_bc;
	Global (){
		tag = 0;
		two_bc = '0';
	}
};

class pm_update : public branch_update{
public:
	unsigned int address;
	unsigned int global_index;
	
	bool final_prediction;
	
	bool bimodal_prediction;
	bool global_prediction;
};

class pm_predictor : public branch_predictor{
public:
	
	//Part A - bimodal
	#define BIMODAL_INDEX_BITS 12
	unsigned int	bimodal_counters[1<< BIMODAL_INDEX_BITS];
	unsigned int	bimodal_index;	
	unsigned int	bimodal_history;	//Not used in decision, only to keep track of performance
	
	//PART B - global
	#define GLOBAL_HISTORY_LENGTH 15
	#define GLOBAL_TABLE_BITS 15
	unsigned int	global_history;
	Global	global_counters[4][1 << GLOBAL_TABLE_BITS];
	bool valid;
	unsigned int row;
	unsigned int gtag;
	
	//PART C - GENERAL USE
	//Shared	
	pm_update u;
	branch_info bi;
	
	//------------------------
	//constructor 
	//------------------------
	pm_predictor(void) : global_history(0), valid(true), row(0), gtag(0){
		//bimodal table
		memset(bimodal_counters, 0, sizeof(bimodal_counters));
		
		//global counter
		for(int i=0; i<4; i++)
			for (int j=0; j< (1 << GLOBAL_TABLE_BITS); j++)
				global_counters[i][j] = Global();
	}
	
	//-------------------------------------------------------------------
	//predict from bimodal first and then global, if global tag cannot be found  
	//in the counter table then final prediction is from bimodal prediction
	//-------------------------------------------------------------------
	branch_update *predict (branch_info & b){
		bi = b;
		unsigned int hash;
		unsigned int done = 0;
		
		//Conditional jump
		if(b.br_flags & BR_CONDITIONAL){
			u.address = b.address;
			
			
			//PART A - make predictions for both bimodal and global
			//Bimodal
			bimodal_index = u.address & (( 1 << (BIMODAL_INDEX_BITS)) -1);
			
			if(bimodal_counters[bimodal_index] >=2){
				u.bimodal_prediction = true;
			}else{
				u.bimodal_prediction = false;
			}
			
			//global
			hash = (global_history  << ( GLOBAL_TABLE_BITS - GLOBAL_HISTORY_LENGTH)) ^ (b.address & ((1 << GLOBAL_TABLE_BITS) -1 ));
			u.global_index = hash >> 6;
			gtag = hash & 63;
			for (int i = 0; i<4; i++){
				if (gtag == global_counters[i][u.global_index].tag) {
					valid = true;
					u.global_prediction = (global_counters[i][u.global_index].two_bc)>>1;
					row = i;
					done = 1;
					break;
				}
			}
			
			if (done == 0)
				valid = false;
			
			//PART B - make final prediction base on global table hit
			if (valid == true) {
				u.final_prediction = u.global_prediction;
				u.direction_prediction(u.global_prediction);
			}
			else {
				u.final_prediction = u.bimodal_prediction;
				u.direction_prediction(u.bimodal_prediction);
			}
			
		//No conditional jump, 100% taken
		}else{
			u.target_prediction(true);
		}
		
		u.target_prediction(0);
		return &u; 
	}
	
	//-------------------------------------------------------------------
	//update bimodal and global counter tables. Specificly, for the global counter table, 
	//either add new tag or replace tag at random row
	//-------------------------------------------------------------------
	void update (branch_update *u , bool taken, unsigned int target){
		unsigned int added = 0;
		if(bi.br_flags & BR_CONDITIONAL){
			//First, bimodal counter table
			bimodal_index = ((pm_update*)u)->address & ((1 << (BIMODAL_INDEX_BITS)) -1);
			
			if(taken){
				if(bimodal_counters[bimodal_index] < 3){
					bimodal_counters[bimodal_index]++;
				}		
			}else{
				if(bimodal_counters[bimodal_index] > 0){
					bimodal_counters[bimodal_index]--;
				}
			}
			
			//Second, global counter table
			if (valid == true) {
				unsigned char *global_counter = &global_counters[row][((pm_update*)u)->global_index].two_bc;
				if(taken){
					if(*global_counter < 3){
						(*global_counter)++;
					}
				}else{
					if(*global_counter > 0){
						(*global_counter)--;
					}
				}	
			
			}else{
				//add new tag at empty slot
				for (int i=0; i<4; i++){
					if (global_counters[i][((pm_update*)u)->global_index].tag == 0){
							global_counters[i][((pm_update*)u)->global_index].tag = gtag;
							global_counters[i][((pm_update*)u)->global_index].two_bc = '0';
							added = 1;
							break;
					}
				}	
				
				//replace random tag position
				if (added == 0) {
					srand(time(0));
					row = rand() % 4;
					global_counters[row][((pm_update*)u)->global_index].tag = gtag;
					global_counters[row][((pm_update*)u)->global_index].two_bc = '0';
				}
			}
			
			//Update global history
			global_history <<=1;
			global_history |= taken;
			global_history &= (1 << GLOBAL_HISTORY_LENGTH)-1;
		}		
	}	
};

//
// Complete Pentium M branch predictors for extra credit
// This class implements the complete Pentium M branch prediction units. 
// It implements both branch target prediction and branch outcome predicton. 
class cpm_update : public branch_update {
public:
        unsigned int index;
};

class cpm_predictor : public branch_predictor {
public:
        cpm_update u;

        cpm_predictor (void) {
        }

        branch_update *predict (branch_info & b) {
            u.direction_prediction (true);
            u.target_prediction (0);
            return &u;
        }

        void update (branch_update *u, bool taken, unsigned int target) {
        }

};


